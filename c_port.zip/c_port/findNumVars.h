//findNumVars.h
// - header file for findNumVars.c

#ifndef FINDNUM_H	// header guard
#define FINDNUM_H

// findNumVars function declaration
int findNumVars(char *config_filename, char *key_start, char *key_end);	

#endif				// FINDNUM_H


