/* 
 * Academic License - for use in teaching, academic research, and meeting 
 * course requirements at degree granting institutions only.  Not for 
 * government, commercial, or other organizational use. 
 * File: _coder_clcDP_port_info.h 
 *  
 * MATLAB Coder version            : 2.8 
 * C/C++ source code generated on  : 21-Jun-2016 17:44:08 
 */

#ifndef ___CODER_CLCDP_PORT_INFO_H__
#define ___CODER_CLCDP_PORT_INFO_H__
/* Include Files */ 
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"


/* Function Declarations */ 
extern const mxArray *emlrtMexFcnResolvedFunctionsInfo(void);

#endif
/* 
 * File trailer for _coder_clcDP_port_info.h 
 *  
 * [EOF] 
 */
