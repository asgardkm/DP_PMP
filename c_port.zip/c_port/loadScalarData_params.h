// loadScalarData_params.h
// header file for loadScalarData_params.c, one ofthe main input-reading function
// created on 28.06.2016 - asgard kaleb marroquin
#include "./codegen/lib/clcDP_port/clcDP_port_types.h"

// function declaration
#ifndef INIT_DECLARATION_PARAMS
#define INIT_DECLARATION_PARAMS
struct0_T loadScalarData_params(char *mainConfigDir);
#endif

