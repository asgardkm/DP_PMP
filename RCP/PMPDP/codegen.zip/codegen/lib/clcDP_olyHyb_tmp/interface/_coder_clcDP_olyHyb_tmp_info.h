/* 
 * Academic License - for use in teaching, academic research, and meeting 
 * course requirements at degree granting institutions only.  Not for 
 * government, commercial, or other organizational use. 
 * File: _coder_clcDP_olyHyb_tmp_info.h 
 *  
 * MATLAB Coder version            : 2.8 
 * C/C++ source code generated on  : 08-Jun-2016 14:22:05 
 */

#ifndef ___CODER_CLCDP_OLYHYB_TMP_INFO_H__
#define ___CODER_CLCDP_OLYHYB_TMP_INFO_H__
/* Include Files */ 
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"


/* Function Declarations */ 
extern const mxArray *emlrtMexFcnResolvedFunctionsInfo(void);

#endif
/* 
 * File trailer for _coder_clcDP_olyHyb_tmp_info.h 
 *  
 * [EOF] 
 */
