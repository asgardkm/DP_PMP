/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * _coder_clcDP_olyHyb_tmp_info.h
 *
 * Code generation for function 'clcDP_olyHyb_tmp'
 *
 */

#ifndef ___CODER_CLCDP_OLYHYB_TMP_INFO_H__
#define ___CODER_CLCDP_OLYHYB_TMP_INFO_H__
/* Include files */
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"


/* Function Declarations */
extern const mxArray *emlrtMexFcnResolvedFunctionsInfo(void);

#endif
/* End of code generation (_coder_clcDP_olyHyb_tmp_info.h) */
